This Project contains all the helping functions for simple interest!!.
